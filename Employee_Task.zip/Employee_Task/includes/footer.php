
   <div class="footer_w3ls">
      <div class="container">
         <div class="footer_bottom">
            <div class="col-md-9 footer_bottom_grid">
               <div class="footer_bottom1">
                  <a href="index.html">
                     <h2><span class="fa fa-signal" aria-hidden="true"></span> Employee Task <label>Management System</label></h2>
                  </a>
                  <p>Employee Task Management System @ 2022</p>
               </div>
            </div>
            <div class="col-md-3 footer_bottom_grid">
               <h6>Follow Us</h6>
               <div class="social">
                  <ul>
                     <li><a href="#"><i class="fa fa-facebook"></i></a></li>
                     <li><a href="#"><i class="fa fa-twitter"></i></a></li>
                     <li><a href="#"><i class="fa fa-rss"></i></a></li>
                  </ul>
               </div>
            </div>
            <div class="clearfix"> </div>
         </div>

      </div>
   </div>
   <!-- //footer -->