 <div class="container-fluid">
                     <div class="footer">
                        <p>Employee Task Management System. All rights reserved.</p>
                     </div>
                  </div>